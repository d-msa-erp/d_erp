package kr.co.d_erp.models;


public class init {

}
