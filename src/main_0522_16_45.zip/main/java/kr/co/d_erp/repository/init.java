package kr.co.d_erp.repository;

public class init {

}
